package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	int num1=0;
    int num2=1;
    int num3;
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        System.out.print(num1+" ");
        System.out.print(num2+" ");
        while(n>2)
        {
            num3=num2+num1;
            System.out.print(num3+" ");
            num1=num2;
            num2=num3;

            n--;
        }
    }
}
