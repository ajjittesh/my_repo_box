package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String get_str = sc. next();
        String str = get_str.toLowerCase();
        int len = str.length();
        int i=0,j=len-1;
        while(i<j) {
            if (str.charAt(i) != str.charAt(j)) {
                System.out.println("not a palindrome");
                return;
            }
            i++;
            j--;
        }
        System.out.println("a palindrome");
        }
    }

